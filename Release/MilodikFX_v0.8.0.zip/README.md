# MilodikFX v0.8.0 - Standalone Audio Effects Suite

MilodikFX is a modern, professional audio effects application featuring an embedded web UI, real-time audio processing, and a comprehensive DSP chain.

## Quick Start

1. **Extract** the MilodikFX_v0.8.0.zip file to your desired location
2. **Double-click** MilodikFX.exe to launch the application
3. Your default browser will open automatically with the UI
4. Select your audio device from the left panel
5. Start adding effects and processing audio!

## System Requirements

- **OS**: Windows 10 or Windows 11 (64-bit)
- **Audio**: Any DirectSound-compatible audio interface
- **Browser**: Modern browser (Chrome, Edge, Firefox) for UI
- **Disk Space**: ~50 MB free space
- **RAM**: 512 MB minimum

## Features

✨ **Modern React Web Interface**
- Light/Dark/High-Contrast themes
- Responsive controls
- Real-time parameter visualization

🎚️ **Professional DSP Chain**
- Clean Boost (Gain: 0-24 dB)
- Overdrive (Drive: 0-100%, Level: 0-100%)
- 3-Band EQ (Bass/Mid/Treble: ±12 dB)
- Compressor (Input Gain, Threshold, Ratio, Attack, Release)
- Reverb (Room Size, Dry/Wet, Decay, Width)
- Tone Stack (Bass/Mid/Treble: ±12 dB)

📊 **Real-Time Monitoring**
- Input/Output level metering
- CPU load indicator
- Peak hold and decay visualization
- Clipping detection

🎛️ **Audio Device Management**
- Multi-device support
- Sample rate configuration
- Buffer size adjustment
- Channel routing options

💾 **Preset Management**
- Save/Load custom presets
- Organized preset library
- Quick preset switching

## File Structure

```
MilodikFX_v0.8.0/
├── MilodikFX.exe           (Main application executable)
├── resources/
│   └── ui/web/             (Frontend files)
│       ├── index.html      (Main UI)
│       └── assets/         (JS/CSS bundles)
├── README.md               (This file)
└── RELEASE_NOTES.txt       (Version history)
```

## Controls

### Audio Device Panel (Left)
- **Select Device**: Choose your audio input/output device
- **Sample Rate**: Set audio sample rate
- **Buffer Size**: Configure buffer size

### Monitoring Panel (Top-Right)
- **Monitor**: Toggle input monitoring
- **Mute**: Mute all output
- **Routing**: Select monitoring routing (Input, Output, Mix)
- **Gain**: Adjust monitoring level

### DSP Chain (Main Area)
- **Effect Bypass**: Click effect title to toggle bypass
- **Parameter Knobs**: Turn to adjust effect parameters
- **Footswitches**: Quick enable/disable toggle

## Troubleshooting

**No Audio Device Found**
- Ensure audio drivers are installed
- Try the "Retry Audio" button
- Check Windows Sound Settings

**UI Not Loading**
- Wait 2-3 seconds after launch for server to start
- Try manually visiting http://localhost:3000 in your browser
- Check firewall settings (port 3000)

**Performance Issues**
- Reduce buffer size for lower latency (increases CPU)
- Disable monitoring when not needed
- Reduce DSP chain complexity

**Browser Connection Lost**
- Refresh the browser page
- Close and restart MilodikFX
- Check for port conflicts on port 3000

## Tips & Tricks

1. **Smooth Transitions**: Use Clean Boost before Overdrive for musical results
2. **EQ Sweetening**: Light EQ (+3 dB mid, -2 dB presence) adds presence
3. **Compression Ratio**: Higher ratios (8:1+) create dramatic effects; lower (2:1-4:1) for smoothing
4. **Reverb Blend**: Keep dry/wet under 50% for clarity
5. **Save Presets**: Regularly save your favorite settings for quick recall

## Technical Details

- **Engine**: JUCE Framework v8.0.0
- **Audio Backend**: DirectSound (Windows)
- **Frontend**: React + Vite + Tailwind CSS
- **Architecture**: C++ DSP Core + Embedded Web UI
- **Version**: 0.8.0
- **Build Date**: 2025

## Support & Feedback

For issues, suggestions, or feature requests, please visit the project repository.

## License

See LICENSE file for details.

---

**Enjoy making great sound with MilodikFX!** 🎵
